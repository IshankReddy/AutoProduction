# Digital Marketing Pricing

Our digital marketing services are priced at $200 per month. This includes:
- Social media account management
- One YouTube video per month
- Advertising on all social media platforms
