# Kill any process using port 8000
lsof -ti:8000 | xargs kill -9 2>/dev/null

# Start the FastAPI server
uvicorn main:app --reload --host 0.0.0.0 --port 8080 &

# Start the data vectorizer
python data_vectorizer.py &

# Wait for any process to exit
wait -n

# Exit with status of process that exited first
exit $?

